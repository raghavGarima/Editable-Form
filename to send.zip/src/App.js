import React from 'react';
import './App.css';
import FormToFill from "./componens/FormToFill"

function App() {
  return (
   <>
   <FormToFill />
     </>
  );
}

export default App;
